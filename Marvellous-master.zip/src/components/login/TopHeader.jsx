import React from 'react';
class TopHeader extends React.Component{
    render(){
        return(
            // <div className="navbar-fixed-top align-right">
			// 					<br />
			// 					&nbsp;
			// 					<a id="btn-login-dark" href="#">Dark</a>
			// 					&nbsp;
			// 					<span className="blue">/</span>
			// 					&nbsp;
			// 					<a id="btn-login-blur" href="#">Blur</a>
			// 					&nbsp;
			// 					<span className="blue">/</span>
			// 					&nbsp;
			// 					<a id="btn-login-light" href="#">Light</a>
			// 					&nbsp; &nbsp; &nbsp;
			// 				</div>
			<div></div>
        )
    }
}
export default TopHeader;